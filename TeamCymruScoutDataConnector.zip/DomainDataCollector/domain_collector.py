import inspect

from SharedCode.logger import applogger
from SharedCode.teamcymruscout_exception import TeamCymruScoutException
from SharedCode import consts
from SharedCode.utils import TeamCymruScoutUtility
from SharedCode.team_cymru_scout_client import TeamCymruScoutRestHelper
from SharedCode.get_logs_data import get_logs_data

class DomainDataCollector:
    def __init__(self) -> None:
        self.logs_starts_with = consts.LOGS_STARTS_WITH+" DomainDataCollector:"
        self.input_domain_values = []
        self.watchlist_domain_values = []
        self.utility_obj = TeamCymruScoutUtility(file_path="domain")
        self.rest_helper_obj = TeamCymruScoutRestHelper()
        self.utility_obj.validate_params()
        
    def get_domain_data_into_sentinel(self):
        __method_name = inspect.currentframe().f_code.co_name
        applogger.debug("{}(method={}) Getting domain values from input and fetch data from Team Cymru Scout.".format(self.logs_starts_with, __method_name))
        self.input_domain_values = self.utility_obj.get_data_from_input(indicator_type="domain")
        if len(self.input_domain_values) > 0:
            self.get_domain_details_from_team_cymru_scout_send_to_sentinel(self.input_domain_values)
        self.watchlist_domain_values = self.utility_obj.get_data_from_watchlists(indicator_type="domain")
        if len(self.watchlist_domain_values) > 0:
            self.get_domain_details_from_team_cymru_scout_send_to_sentinel(self.watchlist_domain_values, watchlist_flag=True)
        
    def get_domain_from_input(self):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            if consts.DOMAIN_VALUES:
                self.input_domain_values = [domain.strip() for domain in consts.DOMAIN_VALUES.split(",")]
            else:
                applogger.info("{} (method={}) : No domain values found in the input.".format(self.logs_starts_with, __method_name))
        except Exception as err:
            applogger.error("{}(method={}) {}".format(self.logs_starts_with, __method_name, err))
            raise TeamCymruScoutException()
            
    def get_domain_from_watchlists(self):
        __method_name = inspect.currentframe().f_code.co_name
        try:
            logs_data, flag = get_logs_data(consts.DOMAIN_QUERY)
            if not flag:
                applogger.info("{} (method={}) : No domain values found in the watchlist.".format(self.logs_starts_with, __method_name))
                return None
            watchlist_domains = [data["domain"] for data in logs_data]
            last_checkpoint_data = self.utility_obj.get_checkpoint(indicator_type="domain")
            applogger.debug("Last Checkpoint Data: {}".format(last_checkpoint_data))
            applogger.debug("Last Domain value from watchlist: {}".format(watchlist_domains[-1]))
            if last_checkpoint_data is not None and last_checkpoint_data != watchlist_domains[-1]:
                    self.watchlist_domain_values = watchlist_domains[watchlist_domains.index(last_checkpoint_data)+1: len(watchlist_domains)]
            else:
                self.watchlist_domain_values = watchlist_domains
            applogger.info("{} (method={}) : Domain data to fetch: {}".format(self.logs_starts_with, __method_name, self.watchlist_domain_values))
        except Exception as err:
            applogger.error("{}(method={}) {}".format(self.logs_starts_with, __method_name, err))
            raise TeamCymruScoutException()
            
    def get_domain_details_from_team_cymru_scout_send_to_sentinel(self, domains_list, watchlist_flag=False):
        __method_name = inspect.currentframe().f_code.co_name
        domain_details = []
        for domain in domains_list:
            parsed_domain = domain.replace("[", "").replace("]", "")
            if not self.utility_obj.validate_ip_domain(parsed_domain, consts.DOMAIN_REGEX):
                continue
            domain_data = self.rest_helper_obj.make_rest_call(endpoint=consts.SEARCH_ENDPOINT,params={"query":parsed_domain})
            parse_data = self.parse_domain_data(domain_data)
            # for d in parse_data:
            #     domain_details.append(d)
            applogger.debug("{}(method={}) ip associated with domain {} are {}".format(self.logs_starts_with, __method_name, domain, len(parse_data)))
            domain_details += [d for d in parse_data]
            applogger.debug("{}(method={}) Total domains to post: {}".format(self.logs_starts_with, __method_name, len(domain_details)))
            if len(domain_details) >= consts.POST_CHUNK_SIZE:
                self.rest_helper_obj.send_data_to_sentinel(domain_details, consts.DOMAIN_TABLE_NAME)
                if watchlist_flag:
                    self.utility_obj.save_checkpoint(domain, indicator_type="domain")
                domain_details = []
        if len(domain_details) > 0:
            self.rest_helper_obj.send_data_to_sentinel(domain_details, consts.DOMAIN_TABLE_NAME)
            if watchlist_flag:
                self.utility_obj.save_checkpoint(domain, indicator_type="domain")
            domain_details = []
    
    def parse_domain_data(self, domain_data):
        domain_ips = domain_data.get("ips")
        query = domain_data.get("query")
        start_date = domain_data.get("start_date")
        end_date = domain_data.get("end_date")
        if domain_ips:
            for ip in domain_ips:
                ip.update({"query": query, "start_date": start_date, "end_date": end_date})
        else:
            domain_ips = {"query": query, "start_date": start_date, "end_date": end_date}
        return domain_ips
