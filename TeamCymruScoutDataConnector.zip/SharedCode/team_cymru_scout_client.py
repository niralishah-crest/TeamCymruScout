import requests
import inspect
import json
from requests.auth import HTTPBasicAuth
from .logger import applogger
from .teamcymruscout_exception import TeamCymruScoutException
from .sentinel import MicrosoftSentinel
from . import consts

class TeamCymruScoutRestHelper:
    def __init__(self) -> None:
        self.base_url = consts.CYMRU_SCOUT_BASE_URL
        self.session = requests.Session()
        self.session.headers["Content-Type"] = "application/json"
        self.auth = None
        self.set_authorization_header()
        self.ms_sentinel_obj = MicrosoftSentinel()
    
    def set_authorization_header(self):
        if consts.AUTHENTICATION_TYPE == "API Key":
            applogger.debug("API Key based authentiction is selected.")
            self.session.headers["Authorization"] = "Token: {}".format(consts.API_KEY)
        else:
            self.auth = HTTPBasicAuth(username=consts.USERNAME, password=consts.PASSWORD)
            applogger.info("Username and password based authentiction is selected.")
    
    def make_rest_call(
        self, endpoint, params=None, body=None
    ):
        """To call Team Cymru Scout API.

        Args:
            endpoint (str): endpoint to call.
            params (json, optional): query parameters to pass in API call. Defaults to None.
            body (json, optional): Request body to pass in API call. Defaults to None.

        Returns:
            json: returns json response if API call succeed.
        """
        try:
            __method_name = inspect.currentframe().f_code.co_name
            applogger.debug(
                "(method={}) Calling Team Cymru Scout API for endpoint={} with params={}".format(
                    __method_name, endpoint, params
                )
            )
            request_url = "{}{}".format(self.base_url, endpoint)
            response = self.session.get(
                url=request_url,
                params=params,
                data=body,
                auth=self.auth
            )
            response.raise_for_status()
            if response.status_code == 200:
                response_json = response.json()
                return response_json
        except requests.exceptions.HTTPError as err:
            status_code = err.response.status_code
            if status_code == 401:
                error_msg = "Please verify the provided credentials."
                applogger.error(f"{error_msg}: {err}")
                raise TeamCymruScoutException()

            elif status_code == 429:
                error_msg = "Team Cymru Scout API Limit Exceeded."
                applogger.error(f"{error_msg}: {err}, headers={err.response.headers}")
                raise TeamCymruScoutException()
            
            else:
                applogger.error(err)
                raise TeamCymruScoutException()
        except requests.exceptions.RequestException as err:
            applogger.error(err)
            raise TeamCymruScoutException(
                "Error while connecting to DataminrPulse API: {}".format(err)
            )
        return response
    
    def send_data_to_sentinel(self, data, table_name):
        body = json.dumps(data)
        self.ms_sentinel_obj.post_data(body, table_name)