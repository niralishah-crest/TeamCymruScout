"""This file includes functions to collect domain details from Team Cymru Scout API for domain provided by user and send it to Sentinel."""

import inspect

from SharedCode.logger import applogger
from SharedCode.teamcymruscout_exception import TeamCymruScoutException
from SharedCode import consts
from SharedCode.utils import TeamCymruScoutUtility
from SharedCode.teamcymruscout_client import TeamCymruScout


class IPDataCollector:
    """Class for fetching IP data from Team Cymru Scout and posting it to Log Analytics Workspace."""

    def __init__(self) -> None:
        """Initialize the object of DomainDataCollector."""
        self.logs_starts_with = consts.LOGS_STARTS_WITH + " IPDataCollector:"
        self.input_ip_values = []
        self.watchlist_ip_values = []
        self.utility_obj = TeamCymruScoutUtility(file_path="ip")
        self.rest_helper_obj = TeamCymruScout()
        self.utility_obj.validate_params()

    def get_ip_data_into_sentinel(self):
        pass